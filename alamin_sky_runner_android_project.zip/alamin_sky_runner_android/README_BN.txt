ALAMIN SKY RUNNER - Android APK project

এই ফোল্ডারটি Android APK তৈরির সোর্স প্রজেক্ট। এই পরিবেশে Android SDK/Gradle ইনস্টল নেই, তাই এখানে সরাসরি APK কম্পাইল করা যায়নি।

ফোন থেকে APK বানানোর সহজ উপায়:
1. GitHub-এ একটি নতুন repository তৈরি করুন (যেমন alamin-sky-runner)।
2. এই ZIP-এর ভেতরের সব ফাইল repository-তে upload করুন।
3. GitHub repository-র Actions ট্যাবে যান।
4. “Build Alamin Sky Runner APK” workflow নির্বাচন করে “Run workflow” চাপুন।
5. Build সফল হলে workflow run খুলে নিচে Artifacts থেকে “Alamin-Sky-Runner-APK” ZIP ডাউনলোড করুন।
6. ZIP খুললে app-debug.apk পাবেন। সেটি Android ফোনে ইনস্টল করুন।

এটি Debug APK; Play Store-এ প্রকাশের জন্য আলাদা signed release build প্রয়োজন।
